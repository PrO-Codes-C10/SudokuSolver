# SudokuSolver
Solves a given input of sudoku puzzle by using backtracking which is an implementation of depth-first-search algorithm.

Input
1)  9 lines of input each denoting each row
2)  Each line contains 9 integers denoting the value at that index
3)  Empty cells are denoted by 0 and non empty cells have to take values from 1 to 9 .(both inclusive)
 
Output

Solved matrix is printed with each row in one line. The entries of a particular row are separated by spaces.
